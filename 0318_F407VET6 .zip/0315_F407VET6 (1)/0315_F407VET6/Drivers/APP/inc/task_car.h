#ifndef __TASK_CAR_H
#define __TASK_CAR_H

void App_Printf( char* format, ... );
void app_Init(void);
void AppObjCreate(void);


#endif