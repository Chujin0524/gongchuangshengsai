#include "main.h"

void APP_MOTOR_2006_Init( void )
{
    //ͣ��
    Weak_mode = 1;
    set_moto_current(&hcan1, 0, 0, 0, 0 );
}

void APP_Motor_2006_WhaleControl( void )
{
    static CAR_XYR_T *ptCarXYR = NULL;
    MAIXCAM_DATA_T *ptMaixCAM_Data = APP_MAIXCAM_GetPoint();
    for(;; )
    {
        xQueueReceive( Queue_MotorHandle, &ptCarXYR, portMAX_DELAY ); //�ȴ��������Ӳ���

        App_Printf( "-----APP_MotorWhaleControl-----\r\n" );
        App_Printf( "ADDR: %04X\r\n", ptCarXYR );
        App_Printf( "DirX: %d\r\n", ptCarXYR->WhaleDirX );
        App_Printf( "PosX: %d\r\n", ptCarXYR->WhalePosX );
        App_Printf( "DirY: %d\r\n", ptCarXYR->WhaleDirY );
        App_Printf( "PosY: %d\r\n", ptCarXYR->WhalePosY );
        App_Printf( "DirR: %d\r\n", ptCarXYR->WhaleDirR );
        App_Printf( "PosR: %d\r\n", ptCarXYR->WhalePosR );
        App_Printf( "-----APP_MotorWhaleControl-----\r\n" );

        if( ptCarXYR->WhalePosX > 0 )
        {
            APP_MOTOR_2006_WHALE_MovePID( ptCarXYR->WhaleDirX, ptCarXYR->WhalePosX );

            ptCarXYR->WhaleDirX = 0;
            ptCarXYR->WhalePosX = 0;
            ptMaixCAM_Data->ucSendFlag = 0;
        }
        if( ptCarXYR->WhalePosY > 0 )
        {
            APP_MOTOR_2006_WHALE_MovePID( ptCarXYR->WhaleDirY, ptCarXYR->WhalePosY );

            ptCarXYR->WhaleDirY = 0;
            ptCarXYR->WhalePosY = 0;
            ptMaixCAM_Data->ucSendFlag = 0;
        }
        if( ptCarXYR->WhalePosR >= 0 )
        {
            APP_MOTOR_2006_WHALE_MovePID( ptCarXYR->WhaleDirR, ptCarXYR->WhalePosR );//֮����ܻ�������

            ptCarXYR->WhaleDirR = 0;
            ptCarXYR->WhalePosR = 0;
        }
    }
}

/*
*********************************************************************************************************
*    �� �� ��: APP_MOTOR_2006_WHALE_MovePID
*    ����˵��: �ǶȻ�����С��ƽ�Ƹ�������
*    ��    ��: _dir  : �궨���bsp.h
*              _clk  : ����
*    �� �� ֵ: ��
*********************************************************************************************************
*/
void APP_MOTOR_2006_WHALE_MovePID( uint8_t _dir, int32_t _clk )
{
    static uint32_t clk1 = 10000;
    static uint32_t clk2 = 5000;
    int flag = 0;
    Weak_mode = 0;
    if( flag == 0 )
    {
        switch( _dir )
        {
        case CarDirection_Forward:
            if( _clk >= clk1 )
//            {
//                SpeedUP_x( 500, 0, _clk, 0.3 * _clk, 0.3 * _clk, yaw0 );
//                Weak_mode = 1;
//            }
//            else if( _clk > clk2 )
            {
                Move_Transfrom( 200, 0, 0, yaw0 );
                if( delay_dis_diagnal( _clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            else
            {
                Move_Transfrom( 25, 0, 0, yaw0 );
                if( delay_dis_diagnal( _clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            break;
        case CarDirection_Backward:
            if( _clk >= clk1 )
//            {
//                SpeedUP_x(-500, 0, _clk, 0.3 * _clk, 0.3 * _clk, yaw0 );
//                Weak_mode = 1;
//            }
//            else if( _clk > clk2 )
            {
                Move_Transfrom(-200, 0, 0, yaw0 );
                if( delay_dis_diagnal(-_clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            else
            {
                Move_Transfrom(-25, 0, 0, yaw0 );
                if( delay_dis_diagnal(-_clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            break;
        case CarDirection_Left:
            if( _clk >= clk1 )
//            {
//                SpeedUP_track( 500, 0, _clk, 0.3 * _clk, 0.3 * _clk, yaw0 );
//                Weak_mode = 1;
//            }
//            else if( _clk > clk2 )
            {
                Move_Transfrom( 0, 200, 0, yaw0 );
                if( delay_distance( _clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            else
            {
                Move_Transfrom( 0, 25, 0, yaw0 );
                if( delay_distance( _clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            break;
        case CarDirection_Right:
            if( _clk >= clk1 )
//            {
//                SpeedUP_track(-500, 0, _clk, 0.3 * _clk, 0.3 * _clk, yaw0 );
//                Weak_mode = 1;
//            }
//            else if( _clk > clk2 )
            {
                Move_Transfrom( 0, -200, 0, yaw0 );
                if( delay_distance(-_clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            else
            {
                Move_Transfrom( 0, -25, 0, yaw0 );
                if( delay_distance(-_clk ) == 1 )
                {
                    Weak_mode = 1;
                    Move_Transfrom( 0, 0, 0, yaw0 );
                }
            }
            break;
        case CarDirection_CCR:
            Move_Transfrom( 0, 0, 0, _clk );
            break;
        case CarDirection_CR:
            Move_Transfrom( 0, 0, 0, _clk );
            break;
        }
    }
}

/*
*********************************************************************************************************
*    �� �� ��: APP_MOTOR_2006_WHALE_Status
*    ����˵��: �ǶȻ�����С��ƽ�Ƹ�������
*    ��    ��: _dir  : �궨���bsp.h
*              _clk  : ����
*    �� �� ֵ: ��
*********************************************************************************************************
*/
void APP_MOTOR_2006_WHALE_Status( STATUS_E _ucStatus )
{
    switch( _ucStatus )
    {
    case STATUS_Start_2_Qr:
        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Backward, 2200 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Left, 5800 );
        break;

    case STATUS_Qr_2_RawArea:
        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Left, 8800 );
        break;

    case STATUS_RawArea_2_ProFirArea:
        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Right, 4500 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_CCR, 180 ); //����ת180��

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Forward, 16500 );
        break;

    case STATUS_ProFirArea_2_ProSecArea:
        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Right, 8100 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Backward, 8000 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_CR, 90 ); //˳��ת90��
        break;

    case STATUS_ProSecArea_2_RawArea:
        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Right, 8900 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Backward, 3600 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_CR, 90 ); //˳��ת90��
        break;

    case STATUS_ProSecArea_2_Start:
        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Backward, 17000 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Right, 9800 );

        APP_MOTOR_2006_WHALE_MovePID( CarDirection_Backward, 1500 );
        break;

    default:
        break;
    }
}

