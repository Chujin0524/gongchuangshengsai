/*
 * user_can.h
 *
 *  Created on: 2023年8月6日
 *      Author: 71492
 */

#ifndef __BSP_CAN_H_
#define __BSP_CAN_H_

void bsp_InitCAN(void);

#endif /* INC_USER_CAN_H_ */
