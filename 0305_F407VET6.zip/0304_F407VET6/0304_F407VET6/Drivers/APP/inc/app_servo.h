#ifndef __APP_SERVO_H
#define __APP_SERVO_H

void APP_SERVO_Jaw(uint8_t _index);
void APP_SERVO_Wrist(uint8_t _index);
void APP_SERVO_Plate(uint8_t _index);

#endif