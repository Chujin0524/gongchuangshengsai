#ifndef __APP_HANDLE_H
#define __APP_HANDLE_H

void APP_HandleMove(void);
void APP_Handle_PickRawArea(uint8_t _ucStatusIndex);
void APP_Handle_Place_All(uint8_t _time, uint8_t _firstIndex, uint8_t _secondIndex, uint8_t _thirdIndex);
void APP_Handle_Pick_All(uint8_t _firstIndex, uint8_t _secondIndex, uint8_t _thirdIndex);

#endif